package com.google.df.webhook;

public class Request {

	private String responseId;
	private String session;
	QueryResult QueryResultObject;
	OriginalDetectIntentRequest OriginalDetectIntentRequestObject;

	// Getter Methods

	public String getResponseId() {
		return responseId;
	}

	public String getSession() {
		return session;
	}

	public QueryResult getQueryResult() {
		return QueryResultObject;
	}

	public OriginalDetectIntentRequest getOriginalDetectIntentRequest() {
		return OriginalDetectIntentRequestObject;
	}

	// Setter Methods

	public void setResponseId(String responseId) {
		this.responseId = responseId;
	}

	public void setSession(String session) {
		this.session = session;
	}

	public void setQueryResult(QueryResult queryResultObject) {
		this.QueryResultObject = queryResultObject;
	}

	public void setOriginalDetectIntentRequest(OriginalDetectIntentRequest originalDetectIntentRequestObject) {
		this.OriginalDetectIntentRequestObject = originalDetectIntentRequestObject;
	}
}
