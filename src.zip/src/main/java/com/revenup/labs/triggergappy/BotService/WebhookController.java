package com.revenup.labs.triggergappy.BotService;

public class WebhookController {


	
}
