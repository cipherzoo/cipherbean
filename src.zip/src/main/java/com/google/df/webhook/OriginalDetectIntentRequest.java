package com.google.df.webhook;

public class OriginalDetectIntentRequest {

}
