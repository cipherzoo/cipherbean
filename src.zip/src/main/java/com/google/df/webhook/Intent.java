package com.google.df.webhook;

public class Intent {
	private String name;
	private String displayName;

	// Getter Methods

	public String getName() {
		return name;
	}

	public String getDisplayName() {
		return displayName;
	}

	// Setter Methods

	public void setName(String name) {
		this.name = name;
	}

	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}
}
