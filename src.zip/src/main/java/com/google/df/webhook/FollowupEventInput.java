package com.google.df.webhook;

public class FollowupEventInput {
	private String name;
	private String languageCode;
	Parameters ParametersObject;

	// Getter Methods

	public String getName() {
		return name;
	}

	public String getLanguageCode() {
		return languageCode;
	}

	public Parameters getParameters() {
		return ParametersObject;
	}

	// Setter Methods

	public void setName(String name) {
		this.name = name;
	}

	public void setLanguageCode(String languageCode) {
		this.languageCode = languageCode;
	}

	public void setParameters(Parameters parametersObject) {
		this.ParametersObject = parametersObject;
	}
}
