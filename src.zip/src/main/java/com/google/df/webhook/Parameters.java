package com.google.df.webhook;

public class Parameters {
	private String param;

	// Getter Methods

	public String getParam() {
		return param;
	}

	// Setter Methods

	public void setParam(String param) {
		this.param = param;
	}
}