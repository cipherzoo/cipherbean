package com.google.df.webhook;

import java.util.ArrayList;

public class QueryResult {
	private String queryText;
	Parameters ParametersObject;
	private boolean allRequiredParamsPresent;
	private String fulfillmentText;
	ArrayList<Object> fulfillmentMessages = new ArrayList<Object>();
	ArrayList<Object> outputContexts = new ArrayList<Object>();
	Intent IntentObject;
	private float intentDetectionConfidence;
	DiagnosticInfo DiagnosticInfoObject;
	private String languageCode;

	// Getter Methods

	public String getQueryText() {
		return queryText;
	}

	public Parameters getParameters() {
		return ParametersObject;
	}

	public boolean getAllRequiredParamsPresent() {
		return allRequiredParamsPresent;
	}

	public String getFulfillmentText() {
		return fulfillmentText;
	}

	public Intent getIntent() {
		return IntentObject;
	}

	public float getIntentDetectionConfidence() {
		return intentDetectionConfidence;
	}

	public DiagnosticInfo getDiagnosticInfo() {
		return DiagnosticInfoObject;
	}

	public String getLanguageCode() {
		return languageCode;
	}

	// Setter Methods

	public void setQueryText(String queryText) {
		this.queryText = queryText;
	}

	public void setParameters(Parameters parametersObject) {
		this.ParametersObject = parametersObject;
	}

	public void setAllRequiredParamsPresent(boolean allRequiredParamsPresent) {
		this.allRequiredParamsPresent = allRequiredParamsPresent;
	}

	public void setFulfillmentText(String fulfillmentText) {
		this.fulfillmentText = fulfillmentText;
	}

	public void setIntent(Intent intentObject) {
		this.IntentObject = intentObject;
	}

	public void setIntentDetectionConfidence(float intentDetectionConfidence) {
		this.intentDetectionConfidence = intentDetectionConfidence;
	}

	public void setDiagnosticInfo(DiagnosticInfo diagnosticInfoObject) {
		this.DiagnosticInfoObject = diagnosticInfoObject;
	}

	public void setLanguageCode(String languageCode) {
		this.languageCode = languageCode;
	}
}