package com.google.df.webhook;

import java.util.ArrayList;

public class Response {
	private String fulfillmentText;
	ArrayList<Object> fulfillmentMessages = new ArrayList<Object>();
	private String source;
	Payload PayloadObject;
	ArrayList<Object> outputContexts = new ArrayList<Object>();
	FollowupEventInput FollowupEventInputObject;

	// Getter Methods

	public String getFulfillmentText() {
		return fulfillmentText;
	}

	public String getSource() {
		return source;
	}

	public Payload getPayload() {
		return PayloadObject;
	}

	public FollowupEventInput getFollowupEventInput() {
		return FollowupEventInputObject;
	}

	// Setter Methods

	public void setFulfillmentText(String fulfillmentText) {
		this.fulfillmentText = fulfillmentText;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public void setPayload(Payload payloadObject) {
		this.PayloadObject = payloadObject;
	}

	public void setFollowupEventInput(FollowupEventInput followupEventInputObject) {
		this.FollowupEventInputObject = followupEventInputObject;
	}
}

