package com.google.df.webhook;

public class DiagnosticInfo {

	// Getter Methods

	// Setter Methods

}
